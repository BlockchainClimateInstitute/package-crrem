from crrem.var import VAR

