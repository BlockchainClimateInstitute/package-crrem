
from crrem.var import Building, Portfolio